---
name: Clinical Elegance
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1b1c1c'
  on-surface-variant: '#42484a'
  inverse-surface: '#303030'
  inverse-on-surface: '#f3f0ef'
  outline: '#72787b'
  outline-variant: '#c2c7ca'
  surface-tint: '#48626d'
  primary: '#06242e'
  on-primary: '#ffffff'
  primary-container: '#1f3a44'
  on-primary-container: '#88a4b0'
  inverse-primary: '#afcbd7'
  secondary: '#725b25'
  on-secondary: '#ffffff'
  secondary-container: '#fcdc99'
  on-secondary-container: '#775f29'
  tertiary: '#21221f'
  on-tertiary: '#ffffff'
  tertiary-container: '#363734'
  on-tertiary-container: '#a1a09b'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#cae7f4'
  primary-fixed-dim: '#afcbd7'
  on-primary-fixed: '#011f28'
  on-primary-fixed-variant: '#304a55'
  secondary-fixed: '#ffdf9c'
  secondary-fixed-dim: '#e2c382'
  on-secondary-fixed: '#251a00'
  on-secondary-fixed-variant: '#59440f'
  tertiary-fixed: '#e4e2dd'
  tertiary-fixed-dim: '#c8c6c2'
  on-tertiary-fixed: '#1b1c19'
  on-tertiary-fixed-variant: '#474743'
  background: '#fcf9f8'
  on-background: '#1b1c1c'
  surface-variant: '#e5e2e1'
  clinical-blue: '#1F3A44'
  heritage-gold: '#C6A96B'
  warm-ivory: '#EFEDE8'
  deep-charcoal: '#222222'
  surface-sand: '#F7F5F2'
typography:
  display-lg:
    fontFamily: EB Garamond
    fontSize: 48px
    fontWeight: '500'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: EB Garamond
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: EB Garamond
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 34px
  headline-md:
    fontFamily: EB Garamond
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-lg:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  margin-mobile: 20px
  margin-desktop: 64px
  gutter: 16px
  container-max: 1200px
---

## Brand & Style
The design system embodies a "Medical Luxury" aesthetic, specifically tailored for a premium Boston-based clientele. It strikes a precise balance between clinical authority and high-end editorial sophistication. 

The visual direction follows a **Corporate / Modern** framework with heavy **Minimalist** influences. It prioritizes whitespace, precision alignment, and a high-fidelity tactile feel. The goal is to evoke a sense of "Advanced Precision"—the feeling of a world-class medical facility located on Newbury Street. 

Key attributes include:
- **Clinical Excellence:** Every interface element feels intentional and technically sound.
- **Sophisticated Warmth:** Moving away from cold "hospital white" toward ivory and sand tones to create a welcoming, high-end environment.
- **Trust & Authority:** Utilizing structured layouts and refined typography to reinforce medical expertise.

## Colors
The palette is rooted in medical professionalism and architectural luxury. 

- **Primary (Clinical Blue):** A deep, intellectual teal-navy used for core brand elements and primary actions. It signals stability and technological advancedness.
- **Secondary (Heritage Gold):** Reserved for subtle accents, badges of excellence, or high-tier membership indicators. It adds a layer of premium "Newbury Street" luxury.
- **Tertiary (Warm Ivory):** The foundational background color. It is softer than pure white, reducing eye strain and adding an approachable, high-end feel.
- **Neutral (Deep Charcoal):** Used exclusively for typography and fine borders to maintain maximum legibility without the harshness of pure black.

## Typography
The typographic hierarchy uses a "High-Contrast Serif/Sans" pairing common in luxury editorial publishing.

- **Headlines:** `EB Garamond` provides a timeless, authoritative, and academic feel. Use optical sizing where available to ensure the delicate serifs remain crisp.
- **Body & UI:** `Hanken Grotesk` is used for all functional text. It is a clean, contemporary Neo-Grotesk that offers exceptional legibility in clinical data and patient forms.
- **Styling Note:** Labels and small captions should often use `label-lg` with uppercase styling and increased letter spacing to differentiate functional UI from narrative content.

## Layout & Spacing
The layout follows a strict 8px soft-grid system to ensure clinical precision. 

- **Mobile:** A 4-column fluid layout with 20px outside margins. Focus on vertical rhythm and "bottom-heavy" ergonomics for easy thumb access to booking actions.
- **Desktop:** A 12-column fixed-grid system centered within a 1200px container. Large-scale editorial imagery should occasionally break the grid to create a premium feel.
- **Negative Space:** Use generous padding (often 48px+) between major content sections to allow the design to "breathe," mimicking the spaciousness of a luxury clinic.

## Elevation & Depth
Depth is conveyed through **Tonal Layering** and **Subtle Soft Shadows**. 

- **Surfaces:** Use `warm-ivory` as the base level. Floating cards use pure `#FFFFFF` to distinguish themselves from the background.
- **Shadows:** Shadows are highly diffused and low-opacity (4-8%). Use a slight Y-axis offset to create a "natural light" effect, suggesting the cards are resting just above the surface.
- **Borders:** Define elements with 1px borders in a slightly darker shade of the background color (`#DEDCD7`) rather than heavy shadows. This maintains a clean, medical-grade aesthetic.

## Shapes
The shape language is "Rounded but Disciplined." 

- **Primary Cards:** Use a consistent 16px radius.
- **Secondary Elements:** Smaller components like input fields use an 8px radius.
- **Buttons:** Primary buttons use a 12px radius to feel approachable yet structured. Avoid full pills for primary buttons to maintain a more "architectural" feel.

## Components
Consistent component styling reinforces the premium medical identity.

- **Buttons:** 
  - *Primary:* Filled `clinical-blue` with white `label-lg` text. 
  - *Secondary:* Ghost style with 1px `deep-charcoal` border.
- **Cards:** White background, 1px fine border, 16px corner radius, and subtle ambient shadow. Use for treatment categories and patient testimonials.
- **Input Fields:** Minimalist style. No background fill, only a bottom border or a very light 4-sided stroke. Focus state should highlight the border in `heritage-gold`.
- **iOS-style Segmented Controls:** Used for switching between "Treatments," "Results," and "Pricing." Features a subtle background track and a sliding white "thumb" indicator.
- **Bottom Sheets:** For booking appointments and detailed treatment info. Includes a slim handle and large, readable headers.
- **Badges:** Small, uppercase labels for "FDA Approved" or "Clinical Study," using the `heritage-gold` color sparingly.
- **Progressive Disclosure:** Use clean accordions for FAQs and medical pre-care instructions to keep the interface uncluttered.